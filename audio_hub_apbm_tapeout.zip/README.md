# Audio Hub APBM Tapeout Skeleton

This package contains a standalone `audio_hub_apbm` module.

Main RTL:

```text
rtl/apbm/audio_hub_apbm.sv
```

Main docs:

```text
docs/audio_hub_apbm.md
docs/rtl_block_diagram.md
```

The APBM is designed as an independent block so that Crossbar, Mixer, Merge and DG can be developed as separate reusable IP blocks.

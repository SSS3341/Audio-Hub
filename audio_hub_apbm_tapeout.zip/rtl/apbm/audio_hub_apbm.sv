// ============================================================================
// Audio Hub APBM - DWC_i2s Service APB Master
// ----------------------------------------------------------------------------
// Tapeout-oriented standalone module.
//
// Role:
//   - Services Synopsys DWC_i2s RX/TX FIFO data registers through APB master.
//   - Consumes DWC_i2s dma_rx_req / dma_tx_req.
//   - Generates DWC_i2s dma_rx_ack / dma_tx_ack.
//   - Talks to Audio Hub Crossbar through a simple decoupled request/ack
//     transaction interface.
//   - Does NOT contain DG/Mixer/Merge processing logic.
//
// Dataflow:
//
//   RX:
//     DWC_i2s dma_rx_req
//       -> APBM APB read DWC_i2s RXDATA
//       -> APBM write transaction to Crossbar
//       -> dma_rx_ack
//
//   TX:
//     DWC_i2s dma_tx_req
//       -> APBM read transaction from Crossbar
//       -> APBM APB write DWC_i2s TXDATA
//       -> dma_tx_ack
//
// Notes:
//   - APB3/APB4 compatible single outstanding transfer.
//   - Single clock domain version.
//   - If DWC_i2s APB clock differs from Audio Hub clock, insert CDC outside.
//   - dma_ack polarity/width may need adaptation to your DWC_i2s configuration.
// ============================================================================

module audio_hub_apbm #(
    parameter int APB_ADDR_W = 32,
    parameter int APB_DATA_W = 32,
    parameter int XBAR_DATA_W = 32,

    parameter logic [APB_ADDR_W-1:0] I2S_BASE_ADDR  = 32'h0000_0000,
    parameter logic [APB_ADDR_W-1:0] I2S_RXDATA_OFF = 32'h0000_0000,
    parameter logic [APB_ADDR_W-1:0] I2S_TXDATA_OFF = 32'h0000_0000,

    // 0: RX has priority over TX when both request.
    // 1: TX has priority over RX.
    // 2: round-robin.
    parameter int ARB_MODE = 2,

    // If set, DWC dma ack is one-cycle pulse after full transaction complete.
    // If clear, ack is level for one cycle as implemented below; keep this as
    // pulse for most robust integration unless DWC_i2s requires level ack.
    parameter bit ACK_PULSE_MODE = 1'b1
)(
    input  logic                    clk,
    input  logic                    rst_n,

    // ------------------------------------------------------------------------
    // Control
    // ------------------------------------------------------------------------
    input  logic                    apbm_en,
    input  logic                    rx_en,
    input  logic                    tx_en,
    input  logic                    soft_flush,

    // ------------------------------------------------------------------------
    // DWC_i2s DMA request/ack side
    // ------------------------------------------------------------------------
    input  logic                    i2s_dma_rx_req,
    output logic                    i2s_dma_rx_ack,

    input  logic                    i2s_dma_tx_req,
    output logic                    i2s_dma_tx_ack,

    // ------------------------------------------------------------------------
    // APB master toward DWC_i2s
    // ------------------------------------------------------------------------
    output logic                    m_psel,
    output logic                    m_penable,
    output logic                    m_pwrite,
    output logic [APB_ADDR_W-1:0]   m_paddr,
    output logic [APB_DATA_W-1:0]   m_pwdata,
    input  logic [APB_DATA_W-1:0]   m_prdata,
    input  logic                    m_pready,
    input  logic                    m_pslverr,

    // ------------------------------------------------------------------------
    // Crossbar write transaction: APBM writes RX sample into fabric
    // ------------------------------------------------------------------------
    output logic                    xbar_wr_req,
    input  logic                    xbar_wr_ack,
    output logic [XBAR_DATA_W-1:0]  xbar_wdata,

    // ------------------------------------------------------------------------
    // Crossbar read transaction: APBM reads TX sample from fabric
    // ------------------------------------------------------------------------
    output logic                    xbar_rd_req,
    input  logic                    xbar_rd_ack,
    input  logic [XBAR_DATA_W-1:0]  xbar_rdata,

    // ------------------------------------------------------------------------
    // Optional backpressure/status from Crossbar
    // ------------------------------------------------------------------------
    input  logic                    xbar_rx_can_accept,
    input  logic                    xbar_tx_has_data,

    // ------------------------------------------------------------------------
    // Status / debug / interrupt source
    // ------------------------------------------------------------------------
    output logic                    busy,
    output logic                    rx_busy,
    output logic                    tx_busy,

    output logic                    err_pslverr_sticky,
    output logic                    err_xbar_stall_sticky,
    output logic                    err_protocol_sticky,

    output logic [31:0]             perf_rx_cnt,
    output logic [31:0]             perf_tx_cnt,
    output logic [31:0]             perf_apb_err_cnt,
    output logic [31:0]             perf_xbar_stall_cnt
);

    localparam logic [APB_ADDR_W-1:0] I2S_RXDATA_ADDR = I2S_BASE_ADDR + I2S_RXDATA_OFF;
    localparam logic [APB_ADDR_W-1:0] I2S_TXDATA_ADDR = I2S_BASE_ADDR + I2S_TXDATA_OFF;

    typedef enum logic [3:0] {
        ST_IDLE,

        ST_RX_APB_SETUP,
        ST_RX_APB_ACCESS,
        ST_RX_XBAR_REQ,
        ST_RX_ACK,

        ST_TX_XBAR_REQ,
        ST_TX_APB_SETUP,
        ST_TX_APB_ACCESS,
        ST_TX_ACK
    } state_e;

    state_e state_q, state_d;

    typedef enum logic [1:0] {
        ARB_LAST_NONE = 2'b00,
        ARB_LAST_RX   = 2'b01,
        ARB_LAST_TX   = 2'b10
    } arb_last_e;

    arb_last_e arb_last_q, arb_last_d;

    logic [APB_DATA_W-1:0] rx_sample_q;
    logic [APB_DATA_W-1:0] tx_sample_q;

    logic choose_rx;
    logic choose_tx;

    logic apb_fire;
    logic apb_error_fire;

    assign apb_fire       = m_psel && m_penable && m_pready;
    assign apb_error_fire = apb_fire && m_pslverr;

    wire rx_req_qualified = apbm_en && rx_en && i2s_dma_rx_req && xbar_rx_can_accept;
    wire tx_req_qualified = apbm_en && tx_en && i2s_dma_tx_req && xbar_tx_has_data;

    // ------------------------------------------------------------------------
    // Arbitration
    // ------------------------------------------------------------------------
    always_comb begin
        choose_rx = 1'b0;
        choose_tx = 1'b0;

        unique case (ARB_MODE)
            0: begin
                choose_rx = rx_req_qualified;
                choose_tx = !rx_req_qualified && tx_req_qualified;
            end

            1: begin
                choose_tx = tx_req_qualified;
                choose_rx = !tx_req_qualified && rx_req_qualified;
            end

            default: begin
                if (rx_req_qualified && tx_req_qualified) begin
                    if (arb_last_q == ARB_LAST_RX) begin
                        choose_tx = 1'b1;
                    end else begin
                        choose_rx = 1'b1;
                    end
                end else begin
                    choose_rx = rx_req_qualified;
                    choose_tx = tx_req_qualified;
                end
            end
        endcase
    end

    // ------------------------------------------------------------------------
    // Next-state and outputs
    // ------------------------------------------------------------------------
    always_comb begin
        state_d    = state_q;
        arb_last_d = arb_last_q;

        m_psel    = 1'b0;
        m_penable = 1'b0;
        m_pwrite  = 1'b0;
        m_paddr   = '0;
        m_pwdata  = '0;

        xbar_wr_req = 1'b0;
        xbar_wdata  = rx_sample_q;

        xbar_rd_req = 1'b0;

        i2s_dma_rx_ack = 1'b0;
        i2s_dma_tx_ack = 1'b0;

        unique case (state_q)
            ST_IDLE: begin
                if (choose_rx) begin
                    state_d = ST_RX_APB_SETUP;
                end else if (choose_tx) begin
                    state_d = ST_TX_XBAR_REQ;
                end
            end

            // ---------------- RX path ----------------
            ST_RX_APB_SETUP: begin
                m_psel    = 1'b1;
                m_penable = 1'b0;
                m_pwrite  = 1'b0;
                m_paddr   = I2S_RXDATA_ADDR;
                state_d   = ST_RX_APB_ACCESS;
            end

            ST_RX_APB_ACCESS: begin
                m_psel    = 1'b1;
                m_penable = 1'b1;
                m_pwrite  = 1'b0;
                m_paddr   = I2S_RXDATA_ADDR;

                if (m_pready) begin
                    state_d = ST_RX_XBAR_REQ;
                end
            end

            ST_RX_XBAR_REQ: begin
                xbar_wr_req = 1'b1;
                xbar_wdata  = rx_sample_q;

                if (xbar_wr_ack) begin
                    state_d    = ST_RX_ACK;
                    arb_last_d = ARB_LAST_RX;
                end
            end

            ST_RX_ACK: begin
                i2s_dma_rx_ack = 1'b1;
                state_d = ST_IDLE;
            end

            // ---------------- TX path ----------------
            ST_TX_XBAR_REQ: begin
                xbar_rd_req = 1'b1;

                if (xbar_rd_ack) begin
                    state_d = ST_TX_APB_SETUP;
                end
            end

            ST_TX_APB_SETUP: begin
                m_psel    = 1'b1;
                m_penable = 1'b0;
                m_pwrite  = 1'b1;
                m_paddr   = I2S_TXDATA_ADDR;
                m_pwdata  = tx_sample_q;
                state_d   = ST_TX_APB_ACCESS;
            end

            ST_TX_APB_ACCESS: begin
                m_psel    = 1'b1;
                m_penable = 1'b1;
                m_pwrite  = 1'b1;
                m_paddr   = I2S_TXDATA_ADDR;
                m_pwdata  = tx_sample_q;

                if (m_pready) begin
                    state_d    = ST_TX_ACK;
                    arb_last_d = ARB_LAST_TX;
                end
            end

            ST_TX_ACK: begin
                i2s_dma_tx_ack = 1'b1;
                state_d = ST_IDLE;
            end

            default: begin
                state_d = ST_IDLE;
            end
        endcase

        if (!apbm_en || soft_flush) begin
            state_d = ST_IDLE;
        end
    end

    // ------------------------------------------------------------------------
    // Sequential
    // ------------------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_q               <= ST_IDLE;
            arb_last_q            <= ARB_LAST_NONE;
            rx_sample_q           <= '0;
            tx_sample_q           <= '0;

            err_pslverr_sticky    <= 1'b0;
            err_xbar_stall_sticky <= 1'b0;
            err_protocol_sticky   <= 1'b0;

            perf_rx_cnt           <= 32'd0;
            perf_tx_cnt           <= 32'd0;
            perf_apb_err_cnt      <= 32'd0;
            perf_xbar_stall_cnt   <= 32'd0;
        end else if (soft_flush) begin
            state_q               <= ST_IDLE;
            arb_last_q            <= ARB_LAST_NONE;
            rx_sample_q           <= '0;
            tx_sample_q           <= '0;

            err_pslverr_sticky    <= 1'b0;
            err_xbar_stall_sticky <= 1'b0;
            err_protocol_sticky   <= 1'b0;

            perf_rx_cnt           <= 32'd0;
            perf_tx_cnt           <= 32'd0;
            perf_apb_err_cnt      <= 32'd0;
            perf_xbar_stall_cnt   <= 32'd0;
        end else begin
            state_q    <= state_d;
            arb_last_q <= arb_last_d;

            if (state_q == ST_RX_APB_ACCESS && m_pready) begin
                rx_sample_q <= m_prdata;
            end

            if (state_q == ST_TX_XBAR_REQ && xbar_rd_ack) begin
                tx_sample_q <= xbar_rdata[APB_DATA_W-1:0];
            end

            if (state_q == ST_RX_ACK) begin
                perf_rx_cnt <= perf_rx_cnt + 32'd1;
            end

            if (state_q == ST_TX_ACK) begin
                perf_tx_cnt <= perf_tx_cnt + 32'd1;
            end

            if (apb_error_fire) begin
                err_pslverr_sticky <= 1'b1;
                perf_apb_err_cnt   <= perf_apb_err_cnt + 32'd1;
            end

            if ((state_q == ST_RX_XBAR_REQ && !xbar_wr_ack) ||
                (state_q == ST_TX_XBAR_REQ && !xbar_rd_ack)) begin
                perf_xbar_stall_cnt <= perf_xbar_stall_cnt + 32'd1;
            end

            // Protocol sanity: APB access phase should only occur after setup.
            if (m_penable && !m_psel) begin
                err_protocol_sticky <= 1'b1;
            end
        end
    end

    assign busy    = (state_q != ST_IDLE);
    assign rx_busy = (state_q == ST_RX_APB_SETUP)  ||
                     (state_q == ST_RX_APB_ACCESS) ||
                     (state_q == ST_RX_XBAR_REQ)   ||
                     (state_q == ST_RX_ACK);

    assign tx_busy = (state_q == ST_TX_XBAR_REQ)   ||
                     (state_q == ST_TX_APB_SETUP)  ||
                     (state_q == ST_TX_APB_ACCESS) ||
                     (state_q == ST_TX_ACK);

endmodule

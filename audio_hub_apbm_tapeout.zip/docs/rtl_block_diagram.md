# APBM RTL Block Diagram

```mermaid
flowchart LR
    I2S["DWC_i2s<br/>RXDATA/TXDATA<br/>dma_req"]
    APBM["audio_hub_apbm<br/>APB master scheduler"]
    XBAR["Audio Hub Crossbar"]
    DG["Digital Gain"]
    MIX["Mixer"]
    MERGE["Merge"]

    I2S -->|dma_rx_req/dma_tx_req| APBM
    APBM -->|dma_rx_ack/dma_tx_ack| I2S

    APBM -->|APB read RXDATA| I2S
    APBM -->|APB write TXDATA| I2S

    APBM -->|wr_req/wdata| XBAR
    XBAR -->|wr_ack| APBM

    APBM -->|rd_req| XBAR
    XBAR -->|rd_ack/rdata| APBM

    XBAR <--> DG
    XBAR <--> MIX
    XBAR <--> MERGE
```

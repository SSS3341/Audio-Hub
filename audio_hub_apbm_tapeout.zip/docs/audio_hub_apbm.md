# Audio Hub APBM

## 模块定位

`audio_hub_apbm` 是独立模块，负责连接：

```text
DWC_i2s APB slave / DMA request
        ↕
Audio Hub APBM
        ↕
Crossbar
```

它不包含 DG、Mixer、Merge，只做：

```text
1. DWC_i2s RXDATA APB read
2. DWC_i2s TXDATA APB write
3. DWC_i2s dma_req/dma_ack service
4. Crossbar wr_req/rd_req transaction
5. RX/TX arbitration
6. status/performance counter
```

## RX transaction

```text
i2s_dma_rx_req
    ↓
APBM reads I2S_RXDATA through APB
    ↓
APBM sends xbar_wr_req with sample
    ↓
xbar_wr_ack
    ↓
i2s_dma_rx_ack pulse
```

## TX transaction

```text
i2s_dma_tx_req
    ↓
APBM sends xbar_rd_req
    ↓
xbar_rd_ack with sample
    ↓
APBM writes I2S_TXDATA through APB
    ↓
i2s_dma_tx_ack pulse
```

## Arbitration

Parameter `ARB_MODE`:

```text
0 = RX priority
1 = TX priority
2 = round-robin
```

Tapeout 默认建议：

```text
ARB_MODE = 2
```

## Crossbar interface

```systemverilog
xbar_wr_req
xbar_wr_ack
xbar_wdata

xbar_rd_req
xbar_rd_ack
xbar_rdata
```

APBM 不关心后面接的是 DG、Mixer、Merge 还是其他 DSP block。

## Tapeout notes

需要项目确认：

1. `I2S_RXDATA_OFF`
2. `I2S_TXDATA_OFF`
3. DWC_i2s `dma_ack` 是否为 pulse 或 level
4. RX/TX 是否需要 burst service
5. 是否多 channel / TDM register
6. APB clock 与 audio hub clock 是否同域
